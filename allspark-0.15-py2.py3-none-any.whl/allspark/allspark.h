#ifndef ALLSPARK_ALLSPARK_H_
#define ALLSPARK_ALLSPARK_H_

#include <functional>
#include <map>
#include <memory>
#include <string>
#include <utility>
#include <vector>

#include "allspark/buffer.h"
#include "allspark/error.h"
#include "allspark/health.h"
#include "allspark/helper.h"
#include "allspark/property.h"
#include "allspark/tracker.h"
#include "boost/utility.hpp"

namespace eas {
namespace allspark {

/** @defgroup ftypes "function types" */

/** @{ */

//! async request on success callback fuction.
typedef std::function<std::string(const std::string &)> OnSuccessCallback;

//! async request on failure callback fuction.
typedef std::function<void(int code, const std::string &)> OnFailureCallback;

/** @} */

/*!
 * @brief support protocol type
 */
enum WireProtocol {
  INVALID_PROTOCOL,   // invalid protocol
  HTTP1_PROTOCOL,     // http1
  HTTP2_PROTOCOL,     // http2
  WEBSOCKET_PROTOCOL  // websocket
};

// forward declare
class Context;
class Service;
class Session;
class QueuedService;
class Channel;
class ConnectionPoolManager;
class BufferSlice;
class Tracker;

///@brief Stream is a Interafce
class Stream : public std::enable_shared_from_this<Stream> {
 public:
  enum ControlType {
    // all
    Invalid_Control = 0x0000,

    // http1
    Http1_Normal = 0x0001,
    Http1_Chunked = 0x0002,
    HandShake_Request = 0x0004,
    HandShake_Response = 0x0008,

    // http2
    Http2_Request = 0x0010,
    Http2_Response = 0x0020,
    Http2_Trailer = 0x0040,
    Http2_Data = 0x0080,
    Http2_StreamEnd = 0x0100,
    Http2_Reset = 0x0200,

    // websocket
    WebSocket_ContinueFrame = 0x0400,
    WebSocket_TextFrame = 0x0800,
    WebSocket_BinaryFrame = 0x1000,
    WebSocket_CloseFrame = 0x2000,
    WebSocket_PingFrame = 0x4000,
    WebSocket_PongFrame = 0x8000,
  };

 public:
  // stream_id
  int64_t stream_id;

  // for proxy
  bool is_local;
  std::shared_ptr<Stream> peer_stream;

 public:
  Stream(std::shared_ptr<Session> session);
  virtual ~Stream();

  // method
  virtual std::string GetMethod() = 0;
  virtual void SetMethod(const std::string &) = 0;

  // url setter/getter
  virtual std::string GetUrlPath() = 0;
  virtual void SetUrlPath(const std::string &url_path) = 0;

  // response code setter/getter
  virtual void SetCode(int code) = 0;
  virtual int GetCode() = 0;

  // header meta setter/getter
  virtual void SetMeta(BufferSlice key, BufferSlice value) = 0;
  virtual std::string GetMeta(BufferSlice key) = 0;

  // get all head meta info
  virtual std::map<std::string, std::string> GetAllMeta() = 0;

  // clear state
  virtual void Clear() = 0;

  // get error
  virtual std::error_code GetError() = 0;

  // have many messages to read when handle once
  virtual bool HasMoreRead() = 0;

  // stream end flag
  virtual bool EndOfStream() = 0;

  // // write stream over
  // virtual void WriteOver() = 0;

  // trailers interface
  virtual std::map<std::string, std::string> ReadTrailers();
  virtual void WriteTrailers(std::map<std::string, std::string> &&);

  // read message info, slice move semantics
  BufferSlice Read();
  void Read(std::string &str);
  std::vector<BufferSlice> ReadMany();

  // read message info, slice copy semantics
  virtual void EnableCopy() = 0;
  virtual BufferSlice ReadCopy() = 0;

  // write message info
  std::error_code Write(BufferSlice &&buf, bool fin = false);
  std::error_code Write(const char *cstr, bool fin = false);
  std::error_code Write(const std::string &str, bool fin = false);
  std::error_code WriteMany(std::vector<BufferSlice> &&bufs, bool fin = false);

  // close
  std::error_code Close(const int code = 0);

  // read control info
  virtual int ReadControl(BufferSlice &) = 0;

  // write contorl info
  virtual std::error_code WriteControl(int type, BufferSlice &&) = 0;

  // update control message.
  void UpdateControl(int type, BufferSlice &&slice) {
    control_type_ = type;
    control_message_ = std::move(slice);
  }

  // stream tracker
  Tracker &tracker() { return tracke_; }

  // return binded session
  std::shared_ptr<Session> session();

  // reset session
  void reset_session(std::shared_ptr<Session> ss);

  // control type helper function
  inline void add_control(int &type, int t) { type = type | t; }
  inline void remove_control(int &type, int t) { type = type & ~t; }
  inline bool has_control(int &type, int t) { return t == (type & t); }
  inline void clear_control(int &type) { type = Invalid_Control; }

 protected:
  // control_type
  int control_type_;

  // control_message
  BufferSlice control_message_;

  virtual BufferSlice DoRead() = 0;
  virtual std::vector<BufferSlice> DoReadMany() = 0;

  virtual std::error_code DoWrite(BufferSlice &&buf, bool fin = false) = 0;
  virtual std::error_code DoWriteMany(std::vector<BufferSlice> &&buf,
                                      bool fin = false) = 0;
  virtual std::error_code DoClose(const int code = 0) = 0;

 private:
  struct Impl;
  Impl *impl_;

  Tracker tracke_;
};

///@brief stream share point alias
typedef std::shared_ptr<Stream> StreamRef;

///@brief stream function is a function for handling a stream.
typedef std::function<void(StreamRef)> StreamFunction;

///@brief stream handler is a interface for handling a stream.
///       this handler is a stateless class, do not store any state while hanle.
class StreamHandler : public std::enable_shared_from_this<StreamHandler>,
                      public DependencyContainer<StreamHandler> {
 public:
  StreamHandler();
  explicit StreamHandler(const std::string &token);
  virtual ~StreamHandler();

  // one connection only auth once for a better performance.
  bool AuthCheck(std::shared_ptr<Stream> stream);

  // handle pulbic interface
  void DoHandle(std::shared_ptr<Stream> stream);

  // handle control message
  virtual bool HandleControl(std::shared_ptr<Stream> stream) { return false; }

  // inject builtin service interface
  void InjectBuiltinService(const std::string &url_path,
                            const std::string &token,
                            allspark::StreamFunction stream_function);

  // setup token
  void SetupDefaultToken(const std::string &token) { default_token_ = token; }

 protected:
  virtual void Handle(std::shared_ptr<Stream> stream) = 0;

 private:
  bool disable_auth_;
  std::string default_token_;
  std::map<std::string, allspark::StreamFunction> url_handler_;
  std::map<std::string, std::string> url_token_;
};

class Service : public DependencyContainer<Service>, boost::noncopyable {
 public:
  explicit Service(const Context &ctx);
  explicit Service(const Context &ctx, const std::string &address, int port);
  ~Service();

  void bind(const std::string &endpoint);
  void bind(const std::string &address, int port);
  int get_bind_port();

  void Run(std::shared_ptr<StreamHandler> stream_handler);

 private:
  struct Impl;
  Impl *impl_;
};

class QueuedService : public DependencyContainer<QueuedService>,
                      boost::noncopyable {
 public:
  QueuedService(Service &srv, const std::string token);
  ~QueuedService();

  std::string Read();
  void Write(const std::string &msg);
  void Error(int error_code, const std::string &error_msg);

  std::string Read(int64_t &id);
  void Write(const std::string &msg, int64_t &id);
  void Error(int error_code, const std::string &error_msg, int64_t &id);

  std::vector<std::string> ReadUpto(std::size_t numb, int64_t timeout);
  void Write(const std::vector<std::string> &responses);
  void Error(const std::vector<int> &error_codes,
             const std::vector<std::string> &responses);

  void InjectBuiltinService(const std::string &url_path,
                            const std::string &token,
                            StreamFunction stream_function);

  Service &service() { return srv_; }

 private:
  struct Impl;
  std::shared_ptr<Impl> impl_;
  Service &srv_;
};

class Channel : public DependencyContainer<Channel>, boost::noncopyable {
 public:
  Channel(Context &ctx, std::function<std::string()> get_endpoint,
          const std::map<std::string, std::string> &options = {});
  Channel(Context &ctx, const std::string &endpoint,
          const std::map<std::string, std::string> &options);
  Channel(Context &ctx, const std::string &uri);

  ~Channel();

  std::string request(const std::string &msg);
  int async_request(std::string msg,  //
                    OnSuccessCallback onsuccess, OnFailureCallback onfailure);

  // request interface with options which can be modified by user.
  std::string request(const std::string &msg,
                      const std::map<std::string, std::string> &opt);
  int async_request(std::string msg,  //
                    OnSuccessCallback onsuccess, OnFailureCallback onfailure,
                    const std::map<std::string, std::string> &opt);

 private:
  struct Impl;
  Impl *impl_;
};

class Context : public DependencyContainer<Context>, boost::noncopyable {
 public:
  Context(std::size_t num_threads);

  Context(std::size_t num_threads, int max_connection_pool_size,
          int recycle_connection_pool_time);

  ~Context();

  void run();
  void stop();

  void apply(std::function<void(void)> func);

  Service *service(const std::string &endpoint);
  Service *service(const std::string &addr, short port);

  QueuedService *queued_service(const std::string &endpoint,
                                const std::string &token);
  QueuedService *queued_service(const std::string &endpoint) {
    return queued_service(endpoint, "");
  }

  Channel *channel(const std::string &endpoint,
                   const std::map<std::string, std::string> &options) {
    return new Channel(*this, endpoint, options);
  }
  Channel *channel(const std::string &uri) { return new Channel(*this, uri); }

  ConnectionPoolManager *GetConnectionPoolManager();

 private:
  struct Impl;
  Impl *impl_;

 public:
  friend class Service;
  friend class Session;
};

}  // namespace allspark
}  // namespace eas

#endif  // ALLSPARK_ALLSPARK_H_
